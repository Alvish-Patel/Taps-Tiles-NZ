<?php
namespace peaceful\marblex\new_class;
require CONST_MARBLEX_DIR . '/inc/customizer/theme-functions.php';

class Helper
{
	public static function test()
	{
		echo "init test";
	}
}

