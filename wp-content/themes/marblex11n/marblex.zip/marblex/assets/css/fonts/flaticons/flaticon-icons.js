{
"icons": [     
"flaticon-bathroom",
"flaticon-blueprint",
"flaticon-bridge-saw",
"flaticon-chisel",
"flaticon-construction",
"flaticon-dining-table",
"flaticon-floor",
"flaticon-hammer",
"flaticon-living-room",
"flaticon-marbles",
"flaticon-modern-art",
"flaticon-panels",
"flaticon-stone",
"flaticon-stones",
"flaticon-suckers",
"flaticon-tile-1",
"flaticon-tile-2",
"flaticon-tile",
"flaticon-tiles-1",
"flaticon-tiles-2",
"flaticon-tiles-3",
"flaticon-tiles",
"flaticon-trowel",
"flaticon-wood"

    ]
  }




