<?php 
if (class_exists('WooCommerce')) {
echo do_shortcode( '[marblex-mini-cart]' ); 
} ?>

